package com.zensar.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author Akansha Shah
 * @Creation_date 4th Oct 2019 6.10PM
 * @Modification_date 9th oct 2019 3.56PM
 * @Version 1.0
 * @Copyright Zensar Technologies. All rights reserved
 * @description It is a persistent class It represent database table Product It
 *              is POJO class
 */
@Entity

public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int customerId;
	@Column(nullable = false)
	@Size(min = 3, max = 50)
	private String customerName;
	@Column(nullable = false)
	@Email
	private String emailId;
	private long contactNo;
	private String gender;
	@Column(nullable = false)
	@Size(min = 3, max = 12)
	private String password;

	@ManyToMany(fetch = FetchType.LAZY)
	@JsonIgnore
	List<Hotel> hotels;
	@OneToMany(mappedBy = "customer")
	@JsonIgnore
	List<HotelBooking> booking;

	public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(int customerId, String customerName, String emailId, long contactNo, String gender,
			String password) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.emailId = emailId;
		this.contactNo = contactNo;
		this.gender = gender;
		this.password = password;
	}

	public List<HotelBooking> getBooking() {
		return booking;
	}

	public void setBooking(List<HotelBooking> booking) {
		this.booking = booking;
	}

	public List<Hotel> getHotels() {
		return hotels;
	}

	public void setHotels(List<Hotel> hotels) {
		this.hotels = hotels;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public long getContactNo() {
		return contactNo;
	}

	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
