package com.zensar.entities;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity

public class HotelBooking {

	@Id
	private int bookId;
	private LocalDate bookingDate;
	private LocalDate checkInDate;
	private LocalDate checkOutDate;
	private int noOfRooms;
	private int Adult;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "customerId")
	@JsonIgnore
	private Customer customer;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "hotelId")
	@JsonIgnore
	private Hotel hotel;

	@OneToMany(mappedBy = "hotelBooking")
	@JsonIgnore
	List<Payment> payment;

	public HotelBooking() {
		// TODO Auto-generated constructor stub
	}
	public HotelBooking(int bookId, LocalDate bookingDate, LocalDate checkInDate2, LocalDate checkOutDate2, int noOfRooms,
			int adult) {
		super();
		this.bookId = bookId;
		this.bookingDate = bookingDate;
		this.checkInDate = checkInDate2;
		this.checkOutDate = checkOutDate2;
		this.noOfRooms = noOfRooms;
		Adult = adult;
	}

	public int getNoOfRooms() {
		return noOfRooms;
	}

	public void setNoOfRooms(int noOfRooms) {
		this.noOfRooms = noOfRooms;
	}

	public int getAdult() {
		return Adult;
	}

	public void setAdult(int adult) {
		Adult = adult;
	}

	public LocalDate getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Hotel getHotel() {
		return hotel;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public List<Payment> getPayment() {
		return payment;
	}

	public void setPayment(List<Payment> payment) {
		this.payment = payment;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public LocalDate getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(LocalDate checkInDate) {
		this.checkInDate = checkInDate;
	}

	public LocalDate getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(LocalDate checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	

}
