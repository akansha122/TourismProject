package com.zensar.controllers;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.entities.Customer;
import com.zensar.entities.HotelBooking;
import com.zensar.entities.Room;
import com.zensar.services.HotelBookingService;
import com.zensar.services.RoomService;

@RestController
public class HotelBookingController {
	@Autowired
	private HotelBookingService hotelBookingService;
	
	@Autowired
	private RoomService roomService;
	
	@GetMapping("/hotelbooking")
	public List<HotelBooking> getAllBooking() {
		return hotelBookingService.getAllBooking();
	}

	@GetMapping("/hotelbooking{id}")
	public HotelBooking getById(@PathVariable("id") int bookId) {
		// TODO Auto-generated method stub
		return hotelBookingService.getById(bookId);
	}

	@PostMapping("/hotelbooking/add")
	public String add(@RequestBody HotelBooking hotelBooking, Room room) throws SQLException {
        if(roomService.validateRoom(room)) {
		hotelBookingService.add(hotelBooking);
		return "Your Booking" + hotelBooking.getBookId() + "is added succesfully";
        }
        else
        	return "This room is not avaiable!! Please choose other room";
	}

	
	@PostMapping("/addHotelBooking")
	public String addBooking(@RequestParam("bookid") int bookId, @RequestParam("bookingDate") LocalDate bookingDate,@RequestParam("checkInDate") LocalDate checkInDate, @RequestParam("chechOutDate") LocalDate checkOutDate,@RequestParam("noOfPerson") int noOfPerson, @RequestParam("adult") int adult) {
		HotelBooking hotelBooking = new HotelBooking(bookId, bookingDate, checkInDate, checkOutDate, noOfPerson, adult);
		hotelBookingService.add(hotelBooking);
		return "new customer" + hotelBooking.getBookId() + "is added succesfully";
	}
	 
	@PutMapping("/hotelbooking/update")
	public String update(@RequestBody HotelBooking hb) {
		if (hotelBookingService.getById(hb.getBookId()) != null) {
			hotelBookingService.update(hb);
			return "updated";
		} else
			return "sorry booking not found";
	}

	@PutMapping("/hotelbooking/delete")
	public String delete(@RequestBody HotelBooking hb) {
		if (hotelBookingService.getById(hb.getBookId()) != null) {
			hotelBookingService.remove(hb);
			;
			return "HotelBooking deleted";
		} else {
			return "HotelBooking not found";
		}
	}
}