package com.zensar.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.entities.Customer;
import com.zensar.services.CustomerService;

//request processer component (like pojo class)

@CrossOrigin
@RestController
public class LoginController {
	@Autowired
	private CustomerService customerService;

	@PostMapping("/login")
	public Customer checkLogin(@RequestBody Customer customer) {
		if (customerService.validateCustomer(customer))
			return customer;
		else
		    return null;
	}
}
