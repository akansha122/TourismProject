package com.zensar.controllers;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.entities.Hotel;
import com.zensar.services.HotelService;

@RestController
@CrossOrigin
public class HotelController {

	@Autowired
	private HotelService hotelService;

	@GetMapping("/hotel")
	public List<Hotel> getAllHotels() throws SQLException {
		return hotelService.findAllHotels();
	}

	@GetMapping("/hotel/{id}")
	public Hotel getHotel(@PathVariable("id") int hotelId) throws SQLException {
		return hotelService.findHotelById(hotelId);

	}

	@PostMapping("/hotel/add")
	public String add(@RequestBody Hotel hotel) throws SQLException {
		hotelService.addHotel(hotel);
		return "new hotel of id: " + hotel.getHotelId() + " is added successfully ";
	}


	@PostMapping("/addhotel")
	public String addHotel(@RequestParam("id") int hotelId, @RequestParam("name") String hotelName,
			@RequestParam("location") String location, @RequestParam("phone") long phoneNo,
			@RequestParam("email") String emailId) throws SQLException {
		Hotel hotel = new Hotel(hotelId,hotelName,location,phoneNo,emailId);
		hotelService.addHotel(hotel);
		return "new hotel is added successfully";
	}

	@PutMapping("hotel/update")
	public String update(@RequestBody Hotel hotel) throws SQLException {
		if (hotelService.findHotelById(hotel.getHotelId()) != null) {
			hotelService.updateHotel(hotel);
			return "hotel is updated successfully" + hotel.getHotelId();
		} else {
			return "sorry hotel is not found";
		}

	}

	@DeleteMapping("hotel/delete")
	public String delete(@RequestBody Hotel hotel) throws SQLException {
		if (hotelService.findHotelById(hotel.getHotelId()) != null) {
			hotelService.updateHotel(hotel);
			return "HOtel is deleted successfully";
		} else {
			return "sorry hotel not found";
		}

	}

}
