package com.zensar.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.entities.Customer;
import com.zensar.services.CustomerService;

@CrossOrigin
@RestController
public class CustomerController {
	@Autowired
	private CustomerService customerService;

	@GetMapping("/customers")
	public List<Customer> getAllCustomers() {
		return customerService.findAllCustomer();
	}

	@GetMapping("/customers/{id}")
	public Customer getCustomer(@PathVariable("id") int customerId) {
		return customerService.findCustomerById(customerId);
	}

	@PostMapping("/customers/add")
	public String add(@RequestBody Customer customer) {
		customerService.addCustomer(customer);
		return "new Customer" + customer.getCustomerId() + "is added succesfully";
	}

	// for form data (for html form)

	@PostMapping("/addcustomer")
	public String addCustomer(@RequestParam("id") int customerId, @RequestParam("name") String name,
 	@RequestParam("email") String email, @RequestParam("contact") long contact, @RequestParam("gender") String gender, @RequestParam("password") String password) {
		Customer customer = new Customer(customerId, name, email, contact, gender, password);
		customerService.addCustomer(customer);
		return "new customer" + customer.getCustomerId() + "is added succesfully";
	}

	@PutMapping("/customer/update")
	public String update(@RequestBody Customer Customer) {
		if (customerService.findCustomerById(Customer.getCustomerId()) != null) {
			customerService.updateCustomer(Customer);
			return "customer " + Customer.getCustomerId() + "is updated";
		} else {
			return "sorry!! Customer not found";
		}
	}

	@DeleteMapping("/customer/delete")
	public String delete(@RequestBody Customer customer) {
		if (customerService.findCustomerById(customer.getCustomerId()) != null) {
			customerService.removeCustomer(customer);
			return "customer " + customer.getCustomerId() + "is deleted";
		} else {
			return "sorry!! Customer not found";
		}
	}

}
