package com.zensar.services;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.zensar.entities.HotelBooking;
import com.zensar.entities.Room;

public interface HotelBookingService {
	void add(HotelBooking hb);

	void update(HotelBooking hb);

	void remove(HotelBooking hb);

	List<HotelBooking> getAllBooking();

	HotelBooking getById(int bookId);
	
//	boolean validateBooking(HotelBooking hotelBooking) throws SQLException;

}
